package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private EditText editTitulo, editAutor;
    private Spinner spinnerCategoria;
    private Switch switchLido;
    private Button btnSalvar;
    private ListView listViewLivros;
    private ArrayAdapter<String> adapter;
    private List<Livro> listaLivros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        editTitulo = findViewById(R.id.editTitulo);
        editAutor = findViewById(R.id.editAutor);
        spinnerCategoria = findViewById(R.id.spinnerCategoria);
        switchLido = findViewById(R.id.switchLido);
        btnSalvar = findViewById(R.id.btnSalvar);
        listViewLivros = findViewById(R.id.listViewLivros);

        // Configurar Spinner
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.categorias, android.R.layout.simple_spinner_item
        );
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoria.setAdapter(spinnerAdapter);

        atualizarLista();

        btnSalvar.setOnClickListener(v -> {
            String titulo = editTitulo.getText().toString().trim();
            String autor = editAutor.getText().toString().trim();
            Object categoriaObj = spinnerCategoria.getSelectedItem();

            if (titulo.isEmpty() || autor.isEmpty() || categoriaObj == null) {
                Toast.makeText(this, R.string.preencha_campos, Toast.LENGTH_SHORT).show();
                return;
            }

            String categoria = categoriaObj.toString();
            boolean lido = switchLido.isChecked();

            db.adicionarLivro(new Livro(0, titulo, autor, categoria, lido));
            Toast.makeText(this, R.string.livro_adicionado, Toast.LENGTH_SHORT).show();
            atualizarLista();
        });

        listViewLivros.setOnItemClickListener((parent, view, position, id) -> {
            Livro livro = listaLivros.get(position);
            editTitulo.setText(livro.getTitulo());
            editAutor.setText(livro.getAutor());
            switchLido.setChecked(livro.isLido());
        });

        listViewLivros.setOnItemLongClickListener((parent, view, position, id) -> {
            Livro livro = listaLivros.get(position);
            db.excluirLivro(livro.getId());
            Toast.makeText(this, R.string.livro_removido, Toast.LENGTH_SHORT).show();
            atualizarLista();
            return true;
        });
    }

    private void atualizarLista() {
        listaLivros = db.getTodosLivros();
        String[] livrosArray = new String[listaLivros.size()];
        for (int i = 0; i < listaLivros.size(); i++) {
            livrosArray[i] = listaLivros.get(i).getTitulo();
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, livrosArray);
        listViewLivros.setAdapter(adapter);
    }
}
