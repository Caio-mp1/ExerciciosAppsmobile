package com.example.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Button;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ListView listView;
    private Button btnAdicionar;
    private ArrayList<Medicacao> lista;
    private MedicacaoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        listView = findViewById(R.id.listViewMedicamentos);
        btnAdicionar = findViewById(R.id.btnAdicionar);

        btnAdicionar.setOnClickListener(v -> {
            Intent intent = new Intent(this, CadastroMedicacao.class);
            startActivity(intent);
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Medicacao med = lista.get(position);
            dbHelper.marcarComoConsumido(med.id, !med.consumido);
            carregarLista();
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            Medicacao med = lista.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Excluir")
                    .setMessage("Deseja excluir o medicamento " + med.nome + "?")
                    .setPositiveButton("Sim", (dialog, which) -> {
                        dbHelper.deletarMedicamento(med.id);
                        carregarLista();
                    })
                    .setNegativeButton("Não", null)
                    .show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarLista();
    }

    private void carregarLista() {
        lista = dbHelper.getTodosMedicamentos();
        if (adapter == null) {
            adapter = new MedicacaoAdapter(this, lista);
            listView.setAdapter(adapter);
        } else {
        }
    }
}
