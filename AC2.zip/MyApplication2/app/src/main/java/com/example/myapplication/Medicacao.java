package com.example.myapplication;

public class Medicacao {
    public int id;
    public String nome;
    public String descricao;
    public int hora;
    public int minuto;
    public boolean consumido;
}
