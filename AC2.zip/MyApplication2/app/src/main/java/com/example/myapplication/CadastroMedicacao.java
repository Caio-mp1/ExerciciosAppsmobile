package com.example.myapplication;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class CadastroMedicacao extends AppCompatActivity {

    private EditText edtNome, edtDescricao;
    private TimePicker timePicker;
    private Button btnSalvar;
    private DatabaseHelper dbHelper;
    private int id = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_medicacao);

        edtNome = findViewById(R.id.edtNome);
        edtDescricao = findViewById(R.id.edtDescricao);
        timePicker = findViewById(R.id.timePicker);
        btnSalvar = findViewById(R.id.btnSalvar);
        dbHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
        if (intent.hasExtra("id")) {
            id = intent.getIntExtra("id", -1);
            Medicacao m = dbHelper.getMedicamentoPorId(id);
            if (m != null) {
                edtNome.setText(m.nome);
                edtDescricao.setText(m.descricao);
                timePicker.setHour(m.hora);
                timePicker.setMinute(m.minuto);
            }
        }

        btnSalvar.setOnClickListener(v -> {
            String nome = edtNome.getText().toString();
            String descricao = edtDescricao.getText().toString();
            int hora = timePicker.getHour();
            int minuto = timePicker.getMinute();

            if (nome.isEmpty()) {
                Toast.makeText(this, "Digite o nome do medicamento", Toast.LENGTH_SHORT).show();
                return;
            }

            if (id == -1) {
                dbHelper.adicionarMedicamento(nome, descricao, hora, minuto);
            } else {
                dbHelper.atualizarMedicamento(id, nome, descricao, hora, minuto);
            }

            Alarme agendar = new Alarme();
            agendar.agendarAlarme(this, nome, hora, minuto);

            finish();
        });
    }
}
