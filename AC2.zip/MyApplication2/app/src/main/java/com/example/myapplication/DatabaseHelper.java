package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "medicamentos.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_MEDICAMENTOS = "medicamentos";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NOME = "nome";
    private static final String COLUMN_DESCRICAO = "descricao";
    private static final String COLUMN_HORA = "hora";
    private static final String COLUMN_MINUTO = "minuto";
    private static final String COLUMN_CONSUMIDO = "consumido"; // 0 = não, 1 = sim

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_MEDICAMENTOS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NOME + " TEXT, " +
                COLUMN_DESCRICAO + " TEXT, " +
                COLUMN_HORA + " INTEGER, " +
                COLUMN_MINUTO + " INTEGER, " +
                COLUMN_CONSUMIDO + " INTEGER DEFAULT 0)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MEDICAMENTOS);
        onCreate(db);
    }

    public long adicionarMedicamento(String nome, String descricao, int hora, int minuto) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(COLUMN_NOME, nome);
        valores.put(COLUMN_DESCRICAO, descricao);
        valores.put(COLUMN_HORA, hora);
        valores.put(COLUMN_MINUTO, minuto);
        valores.put(COLUMN_CONSUMIDO, 0);
        return db.insert(TABLE_MEDICAMENTOS, null, valores);
    }

    public int atualizarMedicamento(int id, String nome, String descricao, int hora, int minuto) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(COLUMN_NOME, nome);
        valores.put(COLUMN_DESCRICAO, descricao);
        valores.put(COLUMN_HORA, hora);
        valores.put(COLUMN_MINUTO, minuto);
        return db.update(TABLE_MEDICAMENTOS, valores, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public void deletarMedicamento(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_MEDICAMENTOS, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public void marcarComoConsumido(int id, boolean consumido) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(COLUMN_CONSUMIDO, consumido ? 1 : 0);
        db.update(TABLE_MEDICAMENTOS, valores, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public ArrayList<Medicacao> getTodosMedicamentos() {
        ArrayList<Medicacao> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_MEDICAMENTOS, null, null, null, null, null, COLUMN_HORA + "," + COLUMN_MINUTO);
        while (cursor.moveToNext()) {
            Medicacao m = new Medicacao();
            m.id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
            m.nome = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOME));
            m.descricao = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRICAO));
            m.hora = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_HORA));
            m.minuto = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MINUTO));
            m.consumido = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CONSUMIDO)) == 1;
            lista.add(m);
        }
        cursor.close();
        return lista;
    }

    public Medicacao getMedicamentoPorId(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_MEDICAMENTOS, null, COLUMN_ID + "=?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor.moveToFirst()) {
            Medicacao m = new Medicacao();
            m.id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
            m.nome = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOME));
            m.descricao = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRICAO));
            m.hora = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_HORA));
            m.minuto = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MINUTO));
            m.consumido = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CONSUMIDO)) == 1;
            cursor.close();
            return m;
        }
        cursor.close();
        return null;
    }
}
