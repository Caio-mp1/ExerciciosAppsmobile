package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.List;

public class MedicacaoAdapter extends BaseAdapter {

    private Context context;
    private List<Medicacao> medicacoes;
    private DatabaseHelper dbHelper;

    public MedicacaoAdapter(Context context, List<Medicacao> medicacoes) {
        this.context = context;
        this.medicacoes = medicacoes;
        this.dbHelper = new DatabaseHelper(context);
    }

    @Override
    public int getCount() {
        return medicacoes.size();
    }

    @Override
    public Object getItem(int position) {
        return medicacoes.get(position);
    }

    @Override
    public long getItemId(int position) {
        return medicacoes.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.medicamento_item, null);
        }

        Medicacao medicacao = medicacoes.get(position);

        TextView nomeMedicamento = convertView.findViewById(R.id.medicamento_nome);
        CheckBox checkboxConsumido = convertView.findViewById(R.id.checkbox_consumido);

        nomeMedicamento.setText(medicacao.nome);
        checkboxConsumido.setChecked(medicacao.consumido);

        checkboxConsumido.setOnCheckedChangeListener((buttonView, isChecked) -> {
            medicacao.consumido = isChecked;
            dbHelper.marcarComoConsumido(medicacao.id, isChecked);
        });

        convertView.setOnLongClickListener(v -> {
            dbHelper.deletarMedicamento(medicacao.id);
            medicacoes.remove(position);
            notifyDataSetChanged(); // Atualiza a lista após a exclusão
            return true;
        });

        return convertView;
    }
}
