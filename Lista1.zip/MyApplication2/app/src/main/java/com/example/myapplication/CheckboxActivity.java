package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class CheckboxActivity extends AppCompatActivity {

    private EditText editTextNome;
    private Button buttonGerarCheckBox;
    private LinearLayout linearLayoutCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkbox);

        editTextNome = findViewById(R.id.editTextNome);
        buttonGerarCheckBox = findViewById(R.id.buttonGerarCheckBox);
        linearLayoutCheckBox = findViewById(R.id.linearLayoutCheckBox);

        buttonGerarCheckBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayoutCheckBox.removeAllViews();

                String nome = editTextNome.getText().toString();

                for (char c : nome.toCharArray()) {
                    CheckBox checkBox = new CheckBox(CheckboxActivity.this);
                    checkBox.setText(String.valueOf(c));
                    linearLayoutCheckBox.addView(checkBox);
                }
            }
        });
    }
}