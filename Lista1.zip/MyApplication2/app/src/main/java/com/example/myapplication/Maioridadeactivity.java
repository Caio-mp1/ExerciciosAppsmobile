package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class Maioridadeactivity extends AppCompatActivity {

    private EditText editTextNome, editTextIdade;
    private Button buttonVerificar;
    private TextView textViewResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maioridade);

        editTextNome = findViewById(R.id.editTextNome);
        editTextIdade = findViewById(R.id.editTextIdade);
        buttonVerificar = findViewById(R.id.buttonVerificar);
        textViewResultado = findViewById(R.id.textViewResultado);

        buttonVerificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editTextNome.getText().toString();
                int idade = Integer.parseInt(editTextIdade.getText().toString());

                if (idade >= 18) {
                    textViewResultado.setText(nome + " é maior de idade.");
                } else {
                    textViewResultado.setText(nome + " é menor de idade.");
                }
            }
        });
    }
}