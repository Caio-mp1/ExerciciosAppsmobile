package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    private EditText editTextNome, editTextIdade, editTextUF, editTextCidade, editTextTelefone, editTextEmail;
    private RadioGroup radioGroupTamanho;
    private CheckBox checkBoxVermelho, checkBoxAzul, checkBoxVerde;
    private Button buttonCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        editTextNome = findViewById(R.id.editTextNome);
        editTextIdade = findViewById(R.id.editTextIdade);
        editTextUF = findViewById(R.id.editTextUF);
        editTextCidade = findViewById(R.id.editTextCidade);
        editTextTelefone = findViewById(R.id.editTextTelefone);
        editTextEmail = findViewById(R.id.editTextEmail);
        radioGroupTamanho = findViewById(R.id.radioGroupTamanho);
        checkBoxVermelho = findViewById(R.id.checkBoxVermelho);
        checkBoxAzul = findViewById(R.id.checkBoxAzul);
        checkBoxVerde = findViewById(R.id.checkBoxVerde);
        buttonCadastrar = findViewById(R.id.buttonCadastrar);

        buttonCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editTextNome.getText().toString();
                int idade = Integer.parseInt(editTextIdade.getText().toString());
                String uf = editTextUF.getText().toString();
                String cidade = editTextCidade.getText().toString();
                String telefone = editTextTelefone.getText().toString();
                String email = editTextEmail.getText().toString();

                int selectedId = radioGroupTamanho.getCheckedRadioButtonId();
                RadioButton radioButtonTamanho = findViewById(selectedId);
                String tamanho = radioButtonTamanho.getText().toString();

                StringBuilder cores = new StringBuilder();
                if (checkBoxVermelho.isChecked()) {
                    cores.append("Vermelho ");
                }
                if (checkBoxAzul.isChecked()) {
                    cores.append("Azul ");
                }
                if (checkBoxVerde.isChecked()) {
                    cores.append("Verde ");
                }

                String mensagem = "Nome: " + nome + "\nIdade: " + idade + "\nUF: " + uf + "\nCidade: " + cidade +
                        "\nTelefone: " + telefone + "\nEmail: " + email + "\nTamanho: " + tamanho + "\nCores: " + cores.toString();

                Toast.makeText(CadastroActivity.this, mensagem, Toast.LENGTH_LONG).show();
            }
        });
    }
}